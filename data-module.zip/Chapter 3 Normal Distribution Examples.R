##################################################################################
####how to use R generate a normal distribution with sample size equals to 100
#### mean = 2, sd = 2
##################################################################################

###generate density distribution 

######create a sequence vector x from -10 to 10 with interval = 0.1

x <- seq(-10, 15, by = 0.1)

######generate density in above vector, save as y

y <- dnorm(x, 2, 2)


##### generate cumulative distribution function for vector x
CF <- pnorm(x, 2, 2)



######plot normal distribution y with both points and lines

plot(x, y, type = "o")

######plot normal distribution y with only lines, line width as 2

plot(x, y, type = "l", lwd = 2, xlim = c(-10, 15))  # xlim is used to define the range of x axis


###generate random sample size = 1000 from a standard normal distribution with mean as 0, sd = 1

z <- rnorm(100, 0, 1)

###plot z to verify the standard normal distribution
par(mfrow = c(1,2))

hist(z, main = "Standard Normal Distribution") # "main" is used to create title for a plot

qqnorm(z, pch = 1, frame = FALSE) # pch = 1 define that we use circle to exhibit each data point, frame = FALSE means that this QQ plot does not include frame

#### draw the line for random distribution 
qqline(z, col = "steelblue", lwd = 2)


### generate 500 sample data from t distribution and plot QQplot
set.seed(1)

y <- rt(1000, 2)

par(mfrow = c(1,2))

hist(y, main = "Student t Distribution") # "main" is used to create title for a plot

qqnorm(y, pch = 1, frame = FALSE) # pch = 1 define that we use circle to exhibit each data point, frame = FALSE means that this QQ plot does not include frame

#### draw the line for random distribution 
qqline(y, col = "steelblue", lwd = 2)



####call the existing dataset named "ToothGrowth" and test whether this sample is normally distributed

data_toothgrowth <- ToothGrowth$len

####generate QQ plots for the above data

qqnorm(data_toothgrowth, pch = 1, frame = FALSE) # pch = 1 define that we use circle to exhibit each data point, frame = FALSE means that this QQ plot does not include frame

#### draw the line for random distribution 
qqline(data_toothgrowth, col = "steelblue", lwd = 2)

#### visualize toothgrowth data density distribution
hist(data_toothgrowth, main = "ToothGrowth Density Distribution")


#########################################################
