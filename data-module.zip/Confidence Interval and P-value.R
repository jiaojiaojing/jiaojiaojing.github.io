install.packages("BSDA")
library(BSDA)


###########################################################

####Does George's measurement well represent true height of spiderman?


#### generate N = 100 sample data as students' measurements
N <- 100

students_measure <- rnorm(100, mean = 180, sd = 3)

mean_students <- 180

sd_students <- 3


#### calculate the value of the statistic

##statistic: X ~ normal distribution (mean = mean_students, sd = sd_students) under Null
mu_G <- 185

stat_george <- mu_G 

stat_george

#### calculate CI of X at 90% under standard normal distribution

L_90 <- qnorm(0.05, mean_students, sd_students)

H_90 <- qnorm(0.95, mean_students, sd_students)

L_90

H_90

#### where mu_G locates regarding to the L and H of 90% CI

#### what if we change the CI to 99%


L_99 <- qnorm(0.005, mean_students, sd_students)

H_99 <- qnorm(0.995, mean_students, sd_students)

L_99

H_99




#### generate N = 100 sample data as students' measurements
N <- 100

students_measure <- rnorm(100, mean = 180, sd = 3)

mean_students <- 180

sd_students <- 3


#### calculate the value of the statistic

##statistic: (X - mean_student)/ sd_students ~ standard normal distribution (mean = 0, sd = 1) under Null
mu_G <- 185

stat_george <- (mu_G - mean_students)/sd_students

stat_george

#### calculate CI of X at 90% under standard normal distribution

L_90 <- qnorm(0.05, 0, 1)

H_90 <- qnorm(0.95, 0, 1)

L_90

H_90

#### where mu_G locates regarding to the L and H of 90% CI

#### what is your result? reject or fail to reject the null?

#### calculate p_value

p_value <- 1 - pnorm(stat_george, 0, 1)

p_value

#### based on the 0.05 cutoff critical value, do you reject or fail to reject the Null?

#### Do your calculations based on CI and p_value consistent with each other? Why? 

#### what if we change the CI to 99%


L_99 <- qnorm(0.005, 0, 1)

H_99 <- qnorm(0.995, 0, 1)

L_99

H_99

#### what about CI with 99% confidence? Do you reject or fail to reject the Null? 
#### what about the P_value? Do 99% CI and p_value give consistent conclusion? 



###Homework

mu_Lucy <- 85  # Lucy's score

All_score <- rnorm(100, 82, 3) # all students' scores in the class




p_value <- 1 - pnorm(186, 180, 3)
